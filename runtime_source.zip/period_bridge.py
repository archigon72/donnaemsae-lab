"""Proof-only execution adapter. Financial formulas exist exclusively in original adapter/Core.
Serialized execution per worker; input and temporary paths are isolated from Windows baseline.
"""
import sys,json,hashlib,shutil,tempfile,platform,sqlite3,decimal,datetime
from pathlib import Path
from decimal import Decimal,Context,setcontext
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'01_MASTER_SOURCE/integration'))
import adapter
CONTEXT={'prec':40,'rounding':'ROUND_HALF_EVEN','Emin':-999999,'Emax':999999,'capitals':1,'clamp':0}
def canonical(v):
 if isinstance(v,Decimal):return str(v)
 if isinstance(v,dict):return {k:canonical(x) for k,x in v.items() if k not in {'core_input_path'}}
 if isinstance(v,(list,tuple)):return [canonical(x) for x in v]
 return v
def normalize(rows):
 ordered=sorted(enumerate(rows),key=lambda t:t[1]['gijunYmd']);excluded=[];retained=[];prefix=True
 for index,row in ordered:
  if prefix and 'fp' in row and row['fp'] is None:
   raw=json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
   excluded.append({'date':adapter.day(row['gijunYmd']),'original_index':index,'row_id':row.get('id',index),'row_sha256':hashlib.sha256(raw).hexdigest(),'reason':'leading NAV null before first valid NAV'})
  else:
   prefix=False;retained.append(row)
 # Invalid non-null values are never skipped. Existing adapter/Core validates them.
 return retained,{'policy_version':'leading-nav-null-common-v1','excluded':excluded,'before_count':len(rows),'after_count':len(retained)}
def run_period(input_bundle,start,end):
 setcontext(Context(**CONTEXT))
 b=input_bundle;work=Path(tempfile.mkdtemp(prefix='period-proof-'))
 original_root,original_data=adapter.ROOT,adapter.DATA
 try:
  nav,receipt=normalize(b['nav_rows']);code=b['ticker'];period=b.get('period','직접지정')
  adapter.ROOT=work;adapter.DATA=work/'04_DATA/runtime_cache';target=adapter.DATA/code;target.mkdir(parents=True)
  manifest=dict(b['manifest']);manifest['analysis_input_policy']=receipt['policy_version']
  for name,obj in [('manifest.json',manifest),('nav_response.json',nav),('distribution_response.json',b['distribution_rows']),('zeroin_metadata.json',b['zeroin_metadata'])]:adapter.write(target/name,obj)
  result=adapter.vm(code,period,start,end,fetch=False)
  # Canonical error additions only cover common normalization all-null input.
  if not nav:
   result['status']='ERROR';result['issues']=[{'code':'nav_invalid','message':adapter.MESSAGES['nav_invalid'],'detail':{'error_code':'INVALID_NAV','reason':'no valid NAV after leading-null exclusion'}}]
  dates=sorted(adapter.day(r['gijunYmd']) for r in nav)
  requested_start,requested_end=start,end
  if dates and period!='직접지정':
   last=datetime.date.fromisoformat(dates[-1]);requested_end=dates[-1]
   requested_start=str(adapter.shift_month(last,int(period[0]))) if period in ('1개월','6개월') else str(adapter.shift_year(last,1)) if period=='1년' else dates[0]
  result['proof_meta']=b['meta'];result['requested_period']={'period':period,'start':requested_start,'end':requested_end};result['normalization']=receipt
  return canonical(result)
 finally:
  adapter.ROOT,adapter.DATA=original_root,original_data
  shutil.rmtree(work,ignore_errors=True)
def environment():
 setcontext(Context(**CONTEXT));ctx=decimal.getcontext()
 return {'python':sys.version,'platform':platform.platform(),'sqlite':sqlite3.sqlite_version,'decimal_lib':getattr(decimal,'__libmpdec_version__',None),'decimal_context':str(ctx),'loaded_modules':sorted(sys.modules),'local_loaded_files':sorted({str(m.__file__) for m in sys.modules.values() if getattr(m,'__file__',None) and str(ROOT) in str(m.__file__)})}
def run_suite(base):
 base=Path(base);cases=json.loads((base/'cases.json').read_text());outputs={};timings={}
 import time
 for case in cases:
  folder='fixtures' if case.get('fixture') else 'bundles';key=case.get('fixture',case['ticker'])
  b=json.loads((base/folder/(key+'.json')).read_text());b['period']=case['period']
  t=time.perf_counter();outputs[case['id']]=run_period(b,case['start'],case['end']);timings[case['id']]=(time.perf_counter()-t)*1000
 return {'environment':environment(),'outputs':outputs,'timings_ms':timings}
