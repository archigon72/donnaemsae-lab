"""v2.3 Integration: original acquisition adapters + immutable app_core.
No financial calculations run in presentation. All created inputs live outside Core.
"""
import sys
sys.dont_write_bytecode = True
import json, csv, hashlib, sqlite3, uuid, traceback, re
from pathlib import Path
from datetime import datetime, timezone, date, timedelta
from decimal import Decimal,getcontext,InvalidOperation
ROOT = Path(__file__).resolve().parents[2]
CORE = ROOT/'01_MASTER_SOURCE/candidate8'
POC = ROOT/'03_REFERENCE/onboarding_poc_original'
sys.path.insert(0,str(POC))
from adapters.funetf import nav, dividends, search
from adapters.zeroin import page
sys.path.insert(0,str(CORE/'main_application_core'))
from app_core import execute
sys.path.insert(0,str(CORE/'health_io_interface'))
from interface import numeric_json
from collector import MAPPING
from brand_policy import BRAND_POLICY, install, product_brand, core_key
install(MAPPING)  # Startup-only routing extension; preserved Core files/formulas stay intact.
AS_OF = '20261002'  # Preserve the existing PoC data cutoff, not wall-clock latest.
DATA = ROOT/'04_DATA/runtime_cache'
UNIVERSE = json.loads((ROOT/'03_REFERENCE/universe_v2_2/universe_master_v2_2.json').read_text(encoding='utf-8'))
INSTRUMENTS = {r['ticker']:r for r in json.loads((CORE/'health_orchestrator/instruments.json').read_text(encoding='utf-8'))}
META = {r['ticker']:r for r in json.loads((CORE/'desktop_ui_v3/instrument_metadata.json').read_text(encoding='utf-8'))['records']}
MESSAGES = {'identification_failed':'종목 식별 실패','funeft_failed':'FunETF 취득 실패','zeroin_failed':'ZeroIn 정보 미제공 또는 취득 실패','nav_unavailable':'NAV 자료 없음 또는 부족','distribution_none':'분배 이력 없음','insufficient_period':'분석기간 부족','core_failed':'기존 Core 분석 불가','benchmark_unavailable':'벤치마크 시계열 후속 연결','adapter_failed':'데이터 변환 실패','ui_render_failed':'화면 표시 실패'}
MESSAGES['nav_invalid']='NAV 원자료 값 오류'

def write(p,obj):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(numeric_json(obj),encoding='utf-8')
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'),parse_float=Decimal)
def day(v):
 s=str(v or '').replace('-','').replace('.','')
 if not re.fullmatch(r'\d{8}',s):return None
 return date(int(s[:4]),int(s[4:6]),int(s[6:8])).isoformat()
def catalog():
 return [{'ticker':r['ticker'],'name':r['official_name'],'isin':r['isin']} for r in UNIVERSE if r['universe_status'] in ('INCLUDED','PROVISIONAL')]
def identity(code):
 return next((r for r in UNIVERSE if r['ticker']==code),None)
def acquire(code):
 """Run existing public FunETF adapters. Never pretend generated cache is old."""
 row=identity(code)
 if not row:raise ValueError('identification_failed')
 target=DATA/code
 if (target/'manifest.json').is_file():return read(target/'manifest.json')
 target.mkdir(parents=True,exist_ok=True)
 hit=search(code)['hit']
 if not hit or hit.get('itemId')!=row['isin']:raise ValueError('identification_failed')
 nr=nav(row['isin'],AS_OF)
 if not isinstance(nr['rows'],list) or not nr['rows']:raise ValueError('nav_unavailable')
 dr=dividends(row['isin'],AS_OF)
 if not isinstance(dr['rows'],list):raise ValueError('funeft_failed')
 write(target/'nav_response.json',nr['rows']);write(target/'distribution_response.json',dr['rows'])
 with (target/'nav.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['date','nav','market_close'])
  for r in sorted(nr['rows'],key=lambda x:x['gijunYmd']):w.writerow([day(r['gijunYmd']),r['fp'],r.get('clsp')])
 zm={};ze=None
 if code not in META:
  try:zm=page(code)
  except Exception as e:ze=type(e).__name__
 write(target/'zeroin_metadata.json',zm)
 dates=sorted(day(r['gijunYmd']) for r in nr['rows'])
 m={'ticker':code,'isin':row['isin'],'source':'FunETF','field':'fp','cache_kind':'new_integration_cache','collected_at_utc':datetime.now(timezone.utc).isoformat(),'data_cutoff':'2026-10-02','first_date':dates[0],'last_date':dates[-1],'observations':len(dates),'nav_url':nr['url'],'distribution_url':dr['url'],'nav_path':str((target/'nav.csv').relative_to(ROOT)),'response_note':'Existing adapter parses response JSON; response cache serializes those unmodified field values, not byte-identical HTTP body.','zeroin_error':ze,'sha256':{n:hashlib.sha256((target/n).read_bytes()).hexdigest() for n in ['nav.csv','nav_response.json','distribution_response.json','zeroin_metadata.json']}}
 write(target/'manifest.json',m);return m

def metadata(code,row):
 m=META.get(code,{})
 z=read(DATA/code/'zeroin_metadata.json') if (DATA/code/'zeroin_metadata.json').exists() else {}
 return {'ticker':code,'isin':row['isin'],'name':row['official_name'],'issuer':m.get('issuer') or z.get('issuer') or INSTRUMENTS.get(code,{}).get('issuer'),'benchmark':m.get('benchmark_name') or z.get('index_name'),'type':m.get('asset_class') or row.get('zeroin_class'),'fee':m.get('annual_total_fee_percent') or z.get('fee'),'strategy':m.get('strategy_summary') or z.get('strategy'),'metadata_as_of':m.get('strategy_as_of'),'links':{'FunETF':row.get('funetf_url') or f"https://www.funetf.co.kr/product/etf/view/{row['isin']}",'ZeroIn':row.get('zeroin_url') or f'https://etf.zeroin.co.kr/etf/{code}'}}

def shift_year(d,n):
 try:return d.replace(year=d.year-n)
 except ValueError:return d.replace(year=d.year-n,day=28)
def shift_month(d,n):
 y,m=divmod(d.year*12+d.month-1-n,12)
 import calendar
 return date(y,m+1,min(d.day,calendar.monthrange(y,m+1)[1]))
def vm(code,period='전체',start=None,end=None,fetch=True):
 getcontext().prec=40  # Decimal context is thread-local, including HTTP request threads.
 row=identity(code)
 result={'schema_version':'2.3','mode':'REAL','ticker':code,'status':'ERROR','metadata':{'ticker':code,'name':row['official_name'] if row else None},'issues':[],'health':None,'series':[],'performance':None,'distribution':None,'market':{'status':'benchmark_unavailable'},'period':period}
 def issue(k,detail=None):result['issues'].append({'code':k,'message':MESSAGES[k],'detail':detail})
 try:
  if not row:issue('identification_failed');return result
  target=DATA/code
  if not (target/'manifest.json').exists():
   if not fetch:issue('nav_unavailable','신규 캐시 미취득');return result
   try:acquire(code)
   except Exception as e:
    write(target/'acquisition_error.json',{'ticker':code,'time_utc':datetime.now(timezone.utc).isoformat(),'exception':type(e).__name__,'cause':str(e)})
    k=str(e) if str(e) in MESSAGES else 'funeft_failed';issue(k,type(e).__name__);return result
  manifest=read(target/'manifest.json');result['cache']=manifest
  result['metadata']=metadata(code,row)
  if not all(result['metadata'].get(k) for k in ['issuer','benchmark','fee','strategy']):issue('zeroin_failed','일부 메타데이터 미제공; 빈값을 추정하지 않음')
  nr=read(target/'nav_response.json');dr=read(target/'distribution_response.json')
  dates=sorted(day(r['gijunYmd']) for r in nr)
  first,last=date.fromisoformat(dates[0]),date.fromisoformat(dates[-1])
  result['available_period']={'start':str(first),'end':str(last),'years':{str(n):first<=shift_year(last,n) for n in [1,3,5]}}
  result['available_period']['months']={str(n):first<=shift_month(last,n) for n in [1,6]}
  result['available_period']['default']='1년' if result['available_period']['years']['1'] else '전체'
  if period=='자동':
   period=result['available_period']['default'];result['period']=period
  issuer=core_key(row['official_name'],result['metadata']['issuer'],MAPPING)
  brand=product_brand(row['official_name'])
  if brand in BRAND_POLICY:
   result['metadata']['brand']=brand  # Preserve legal issuer (including missing), never fabricate it.
  result['core_issuer_key']=issuer
  field=MAPPING.get(issuer)
  if not field:issue('core_failed','UNSUPPORTED_ISSUER: '+str(issuer or row['official_name'].split()[0])+' · Core 지원 운용사/브랜드 미연결');return result
  events=[]
  for r in dr:
   d=day(r.get(field))
   if not d:issue('adapter_failed','Core 날짜 필드 '+field+' 없음');return result
   events.append({'date':d,'amount':Decimal(str(r['divAmt'])),'record_date':day(r.get('basicDt')),'pay_date':day(r.get('payDt'))})
  result['distribution_date_field']=field
  recent=sorted(events,key=lambda r:r['date'])
  from12=str(shift_month(last,12));from6=str(shift_month(last,6))
  e12=[r for r in recent if from12<r['date']<=str(last)]
  sum12=sum((r['amount'] for r in e12),Decimal(0))
  ratio_nav=Decimal(str(max(nr,key=lambda r:r['gijunYmd'])['fp']))
  if not ratio_nav.is_finite() or ratio_nav<=0:raise ValueError('Invalid fp')
  complete12=first<=date.fromisoformat(from12)
  ratio=sum12/ratio_nav*Decimal(100) if complete12 else None
  result['distribution']={'latest':recent[-1] if recent else None,'sum12':sum12,'monthly_average':sum12/Decimal(12) if first<=date.fromisoformat(from12) else None,'sum_recent6':sum((r['amount'] for r in e12 if r['date']>from6),Decimal(0)),'sum_previous6':sum((r['amount'] for r in e12 if r['date']<=from6),Decimal(0)),'history':recent,'ratio':ratio,'ratio_status':'OK' if complete12 else 'insufficient_history','ratio_as_of':str(last),'ratio_nav':ratio_nav,'note':'금액은 1주당. 12개월 달력창 합계; 완전한 12개월 자료일 때만 합계/12 월평균. 이벤트 날짜는 기존 Core 매핑.'}
  if not events:issue('distribution_none')
  finish=last;begin=first
  if period in ('1개월','6개월'):
   begin=shift_month(last,int(period[0]))
   if first>begin:issue('insufficient_period');return result
  elif period in ('1년','3년','5년'):
   begin=shift_year(last,int(period[0]))
   if first>begin:issue('insufficient_period');return result
  elif period=='직접지정':
   try:begin=date.fromisoformat(start or '');finish=date.fromisoformat(end or '')
   except ValueError:issue('insufficient_period','날짜 형식 확인');return result
   if begin<first or finish>last or begin>finish:issue('insufficient_period','자료 범위를 벗어남');return result
  elif period!='전체':issue('insufficient_period','지원하지 않는 기간');return result
  rows=sorted([r for r in nr if str(begin)<=day(r['gijunYmd'])<=str(finish)],key=lambda r:r['gijunYmd'])
  if len(rows)<20:issue('insufficient_period','20개 관측 미만');return result
  actual_start,actual_end=day(rows[0]['gijunYmd']),day(rows[-1]['gijunYmd'])
  result['actual_period']={'start':actual_start,'end':actual_end,'observations':len(rows)}
  run=ROOT/'04_DATA/generated_core_inputs'/code/uuid.uuid4().hex;run.mkdir(parents=True)
  db=run/'input.sqlite'
  with sqlite3.connect(db) as c:
   c.executescript('CREATE TABLE raw_rows(id INTEGER PRIMARY KEY,file_hash TEXT,sheet TEXT,row_number INTEGER);CREATE TABLE nav_observations(id INTEGER PRIMARY KEY,code TEXT,display_date TEXT,nav_decimal TEXT,raw_row_id INTEGER);')
   for i,r in enumerate(rows):
    try:v=Decimal(str(r.get('fp')))
    except (InvalidOperation,ValueError,TypeError):
     issue('nav_invalid',{'error_code':'INVALID_NAV','date':day(r['gijunYmd']),'field':'fp','value':r.get('fp')});return result
    if not v.is_finite() or v<=0:
     issue('nav_invalid',{'error_code':'INVALID_NAV','date':day(r['gijunYmd']),'field':'fp','value':r.get('fp')});return result
    c.execute('INSERT INTO raw_rows VALUES(?,?,?,?)',(i,manifest['sha256']['nav_response.json'],'FunETF etfnav fp',i))
    c.execute('INSERT INTO nav_observations VALUES(?,?,?,?,?)',(i,code,day(r['gijunYmd']),str(v),i))
  ad=run/'archive';ad.mkdir()
  # Only select events in the exact analysis window. Original values/dates unchanged.
  scoped=[r for r in dr if actual_start<=day(r.get(field))<=actual_end]
  write(ad/(code+'.json'),scoped)
  spec={'ticker':code,'isin':row['isin'],'issuer':issuer,'name':row['official_name'],'raw_nav_source':str(db.resolve()),'active':True}
  write(run/'registry.json',[spec])
  response=execute({'feature':'long_term_health','mode':'single','tickers':[code]},registry_path=run/'registry.json',archive_dir=ad,output_dir=run/'outputs')
  write(run/'app_core_response.json',response)
  if response['status']!='OK':issue('core_failed',response['errors']);return result
  h=response['results'][0];result['health']=h
  files=list((run/'outputs').rglob(code+'_daily.json'))
  daily=read(files[0])
  for point in daily:point['raw_index']=Decimal(100)*Decimal(str(point['raw_nav']))/Decimal(str(rows[0]['fp']))
  result['series']=daily
  rawfirst=Decimal(str(rows[0]['fp']));rawlast=Decimal(str(rows[-1]['fp']))
  # Gain from Core-produced daily TR indices; never reimplement reinvestment.
  trfirst=Decimal(str(daily[0]['tr_index']));trlast=Decimal(str(daily[-1]['tr_index']))
  result['performance']={'nav_change':(rawlast/rawfirst-1)*100,'navtr_change':(trlast/Decimal(100)-1)*100,'distribution_sum':sum((r['amount'] for r in recent if actual_start<=r['date']<=actual_end),Decimal(0)),'annualized':None,'nav_first':rawfirst,'nav_last':rawlast}
  result['core_input_path']=str(run.relative_to(ROOT));issue('benchmark_unavailable')
  result['status']='OK';return result
 except Exception as e:
  issue('adapter_failed',type(e).__name__)
  p=ROOT/'04_DATA/logs';p.mkdir(parents=True,exist_ok=True)
  with (p/'errors.log').open('a',encoding='utf-8') as f:f.write(code+'\n'+traceback.format_exc()+'\n')
  return result
