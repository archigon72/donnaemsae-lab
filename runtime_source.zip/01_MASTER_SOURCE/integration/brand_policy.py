"""A-stage explicit FunETF routing configuration, outside immutable Core.

Install once before serving requests. The legacy interface and collector share
one MAPPING dict; keep that object and its eight existing entries unchanged.
This is configuration of supported brand keys, not a replacement calculation.
"""
BRAND_POLICY = {
    'SOL': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'PLUS': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'KIWOOM': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'KoAct': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'HANARO': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    '1Q': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'TIME': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'FOCUS': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'WON': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
    'DAISHIN': {'nav_pipeline': 'funetf_fp', 'distribution_date_field': 'gijunYmd'},
}

def install(mapping):
    for brand, policy in BRAND_POLICY.items():
        field = policy['distribution_date_field']
        if policy['nav_pipeline'] != 'funetf_fp':
            raise ValueError('Unsupported NAV pipeline: ' + brand)
        if brand in mapping and mapping[brand] != field:
            raise ValueError('Conflicting brand date policy: ' + brand)
    mapping.update({brand: p['distribution_date_field'] for brand, p in BRAND_POLICY.items()})

def product_brand(name):
    return name.split(' ', 1)[0] if isinstance(name, str) else None

def core_key(name, legal_issuer, mapping):
    brand = product_brand(name)
    if brand in BRAND_POLICY:
        return brand
    # Preserve the previously approved routing of the original 70 instruments.
    if legal_issuer in mapping:
        return legal_issuer
    if brand in ('KODEX', 'TIGER', 'RISE', 'ACE'):
        return brand
    return legal_issuer
