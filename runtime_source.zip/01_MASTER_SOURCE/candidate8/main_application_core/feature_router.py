"""Feature dispatch only; financial calculations belong to existing modules."""
import sys
from pathlib import Path

FEATURES = {'long_term_health': True, 'evaluation': False, 'overlap': False,
            'monitor': False, 'distribution': False}

def dispatch(request, *, registry_path, archive_dir, output_dir):
    if not FEATURES.get(request['feature'], False):
        raise ValueError('UNSUPPORTED_FEATURE')
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'health_orchestrator'))
    from orchestrator import run
    selection = 'all' if request['mode'] == 'all' else ','.join(request['tickers'])
    return run(registry_path, selection, archive_dir=archive_dir, output_dir=output_dir)
