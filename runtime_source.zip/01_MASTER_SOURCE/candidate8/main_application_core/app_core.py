"""Single public application entry point. Wraps existing I/O unchanged."""
import argparse
import json
import re
from pathlib import Path
from feature_router import FEATURES, dispatch

COUNTS = ('requested_count', 'success_count', 'no_history_count', 'fail_count')

def execute(request, *, registry_path, archive_dir, output_dir):
    response = {'request': request, 'feature': request.get('feature') if isinstance(request, dict) else None,
                'status': 'ERROR', 'summary': dict.fromkeys(COUNTS, 0), 'results': [], 'errors': []}
    def error(layer, code, message, ticker=None):
        response['errors'].append({'layer': layer, 'code': code, 'message': message, 'ticker': ticker})
        return response
    if not isinstance(request, dict):
        return error('request', 'INVALID_REQUEST', '요청은 JSON 객체여야 합니다.')
    if not isinstance(request.get('feature'), str) or not request['feature']:
        return error('request', 'INVALID_FEATURE', 'feature 문자열이 필요합니다.')
    mode = request.get('mode')
    if not isinstance(mode, str) or mode not in ('all', 'single', 'selected'):
        return error('request', 'INVALID_MODE', 'mode는 all/single/selected여야 합니다.')
    tickers = request.get('tickers')
    if not isinstance(tickers, list) or any(not isinstance(t, str) or not re.fullmatch(r'[0-9A-Z]{6}', t) for t in tickers):
        return error('request', 'INVALID_TICKERS', 'tickers는 6자리 코드 문자열 배열이어야 합니다.')
    if (mode == 'all' and tickers) or (mode == 'single' and len(tickers) != 1) or (mode == 'selected' and not tickers):
        return error('request', 'INVALID_SELECTION', 'all은 빈 배열, single은 1종, selected는 1종 이상을 지정합니다.')
    if not FEATURES.get(request['feature'], False):
        return error('feature', 'UNSUPPORTED_FEATURE', '현재 연결되지 않은 기능입니다.')
    try:
        report = dispatch(request, registry_path=registry_path, archive_dir=archive_dir, output_dir=output_dir)
    except Exception:
        return error('execution', 'EXECUTION_FAILURE', '실행환경 또는 결과 저장을 확인하세요.')
    response['summary'] = {k: report[k] for k in COUNTS}
    response['results'] = report['results']
    for diagnostic in report['registry_errors']:
        for code in diagnostic['errors']:
            error('registry', code, '종목 등록 또는 선택을 확인하세요.', diagnostic.get('ticker'))
    for result in report['results']:
        if result['status'] != 'OK':
            error('engine', result['error_code'], result['error_message'], result['ticker'])
    response['status'] = ('OK' if not response['errors'] else
                          'PARTIAL' if report['success_count'] else 'ERROR')
    return response

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', required=True)
    parser.add_argument('--registry', required=True)
    parser.add_argument('--archive', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--response', required=True)
    args = parser.parse_args()
    try:
        request = json.loads(Path(args.request).read_text(encoding='utf-8'))
    except Exception:
        response = {'request': None, 'feature': None, 'status': 'ERROR',
                    'summary': dict.fromkeys(COUNTS, 0), 'results': [],
                    'errors': [{'layer': 'request', 'code': 'INVALID_REQUEST_JSON',
                                'message': '요청 JSON 파일을 확인하세요.', 'ticker': None}]}
    else:
        response = execute(request, registry_path=args.registry, archive_dir=args.archive, output_dir=args.out)
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'health_io_interface'))
        from interface import save_results
        target = Path(args.response)
        if target.exists():
            print(json.dumps({'status': 'ERROR', 'code': 'RESPONSE_EXISTS'})); return 1
        target.parent.mkdir(parents=True, exist_ok=True)
        save_results(response, target)
    except Exception:
        print(json.dumps({'status': 'ERROR', 'code': 'RESPONSE_SAVE_FAILURE'})); return 1
    print(json.dumps({'status': response['status'], 'summary': response['summary']}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
