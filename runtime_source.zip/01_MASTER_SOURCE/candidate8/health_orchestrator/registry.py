"""Instrument metadata and per-row validation; no analysis formulas."""
import json,re
from pathlib import Path
from collections import Counter
FIELDS=('ticker','isin','issuer','name','raw_nav_source')
def load(path):
 try:
  rows=json.loads(Path(path).read_text(encoding='utf-8'))
  if not isinstance(rows,list):raise ValueError('array required')
  return rows,None
 except Exception:return [],'REGISTRY_INVALID'
def validate(rows):
 counts={k:Counter(r.get(k) for r in rows if isinstance(r,dict) and isinstance(r.get(k),str) and r.get(k)) for k in ('ticker','isin')}
 results=[]
 for i,row in enumerate(rows):
  errors=[]
  if not isinstance(row,dict):errors=['REGISTRY_INVALID']
  else:
   for k in FIELDS:
    if not isinstance(row.get(k),str) or not row[k].strip():errors.append('MISSING_'+k.upper())
   if 'MISSING_TICKER' not in errors and not re.fullmatch(r'[0-9A-Z]{6}',row['ticker']):errors.append('INVALID_TICKER')
   if 'MISSING_ISIN' not in errors and not re.fullmatch(r'[A-Z]{2}[A-Z0-9]{9}[0-9]',row['isin']):errors.append('INVALID_ISIN')
   for k in ('ticker','isin'):
    if isinstance(row.get(k),str) and counts[k][row[k]]>1:errors.append('DUPLICATE_'+k.upper())
   if not isinstance(row.get('active'),bool):errors.append('INVALID_ACTIVE')
  results.append({'row_index':i,'ticker':row.get('ticker') if isinstance(row,dict) else None,'valid':not errors,'errors':errors})
 return results
def standard_input(row):return {k:row[k] for k in FIELDS}
