"""Calls public I/O only; computes no financial metrics."""
import sys,json,datetime,uuid,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'health_io_interface'))
from interface import run_one,save_results
from registry import load,validate,standard_input

def run(registry_path, selection='all', *, archive_dir, output_dir):
 rows,load_error=load(registry_path);diagnostics=validate(rows)
 requested=None if selection=='all' else list(dict.fromkeys(selection.split(',')))
 selected=[]
 for i,row in enumerate(rows):
  if requested is None:
   # Invalid active values require a diagnostic rather than silent omission.
   choose=not isinstance(row,dict) or row.get('active') is not False
  else:choose=isinstance(row,dict) and row.get('ticker') in requested
  if choose:selected.append(i)
 run_id=uuid.uuid4().hex;work=Path(output_dir)/run_id;work.mkdir(parents=True,exist_ok=False)
 results=[];registry_errors=[]
 for i in selected:
  diagnostic=diagnostics[i]
  if not diagnostic['valid']:
   registry_errors.append(diagnostic);continue
  try:
   result=run_one(standard_input(rows[i]),archive_dir=archive_dir,output_dir=work/str(i))
  except Exception:
   schema=json.loads((Path(__file__).resolve().parents[1]/'health_io_interface/output_schema.json').read_text())
   result={k:None for k in schema['required']}
   result.update({k:rows[i][k] for k in ('ticker','isin','issuer','name')})
   result.update(interface_version='1.0',status='FAIL',error_code='ENGINE_FAILURE',error_message='종목 실행에 실패했습니다.')
  results.append(result)
 unknown=[] if requested is None else [t for t in requested if not any(isinstance(r,dict) and r.get('ticker')==t for r in rows)]
 for t in unknown:registry_errors.append({'row_index':None,'ticker':t,'valid':False,'errors':['UNKNOWN_TICKER']})
 if load_error:registry_errors.append({'row_index':None,'ticker':None,'valid':False,'errors':[load_error]})
 report={'run_id':run_id,'executed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selection':selection,'requested_count':len(selected)+len(unknown)+(1 if load_error else 0),'success_count':sum(r['status']=='OK' for r in results),'no_history_count':sum(r['status']=='NO_HISTORY' for r in results),'fail_count':sum(r['status']=='FAIL' for r in results)+len(registry_errors),'registry_fail_count':len(registry_errors),'engine_fail_count':sum(r['status']=='FAIL' for r in results),'registry_validation':diagnostics,'registry_errors':registry_errors,'results':results}
 save_results(report,work/'run_results.json')
 return report

def main():
 p=argparse.ArgumentParser();p.add_argument('selection',help='all or ticker or comma-separated tickers');p.add_argument('--registry',required=True);p.add_argument('--archive',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 r=run(a.registry,a.selection,archive_dir=a.archive,output_dir=a.out)
 print(json.dumps({k:r[k] for k in ('run_id','requested_count','success_count','no_history_count','fail_count')},ensure_ascii=False))
if __name__=='__main__':main()
