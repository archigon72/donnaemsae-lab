"""v1 public adapter. Frozen engine files are copied unchanged; no live collection."""
import json,re,sys
from pathlib import Path
from decimal import Decimal
sys.path.insert(0,str(Path(__file__).resolve().parent/'engine'))
from run import execute
from collector import MAPPING
VERSION='1.0'
MEASURES=['start_date','end_date','observations','dividend_events','raw_mdd','raw_hwm_date','raw_trough_date','raw_recovery_date','raw_recovery_days','raw_recovered','navtr_mdd','navtr_hwm_date','navtr_trough_date','navtr_recovery_date','navtr_recovery_days','navtr_recovered','drawdown_reduction_pp','raw_recovery_calendar_days','navtr_recovery_calendar_days']
MESSAGES={'INVALID_INPUT':'필수 입력 또는 입력 형식이 올바르지 않습니다.','UNSUPPORTED_ISSUER':'지원하지 않는 운용사입니다.','SOURCE_UNAVAILABLE':'입력 원자료를 읽을 수 없습니다.','NO_HISTORY':'해당 종목의 Raw NAV 이력이 없습니다.','NAV_JOIN_MISSING':'분배락일과 같은 날짜의 Raw NAV가 없습니다.','INVALID_DIVIDEND':'분배 이벤트 검증에 실패했습니다.','INVALID_NAV':'Raw NAV 검증에 실패했습니다.','ENGINE_FAILURE':'종목 실행에 실패했습니다.','OUTPUT_FAILURE':'결과 자료를 저장할 수 없습니다.'}
def empty(request):
 r={k:request.get(k) if isinstance(request,dict) else None for k in ('ticker','isin','issuer','name')}
 r.update(interface_version=VERSION,status='FAIL',error_code=None,error_message=None)
 r.update({k:None for k in MEASURES});return r
def fail(result,code,status='FAIL'):
 result.update(status=status,error_code=code,error_message=MESSAGES[code]);return result
def run_one(request, *, archive_dir, output_dir):
 """Required archive_dir selects preserved FunETF responses; never accesses network."""
 result=empty(request)
 if not isinstance(request,dict) or any(not isinstance(request.get(k),str) or not request[k].strip() for k in ('ticker','isin','issuer','name','raw_nav_source')):return fail(result,'INVALID_INPUT')
 if not re.fullmatch(r'[0-9A-Z]{6}',request['ticker']) or not re.fullmatch(r'[A-Z]{2}[A-Z0-9]{9}[0-9]',request['isin']):return fail(result,'INVALID_INPUT')
 if request['issuer'] not in MAPPING:return fail(result,'UNSUPPORTED_ISSUER')
 db=Path(request['raw_nav_source']);archive=Path(archive_dir)
 if not db.is_file() or not (archive/(request['ticker']+'.json')).is_file():return fail(result,'SOURCE_UNAVAILABLE')
 try:
  out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
 except Exception:return fail(result,'OUTPUT_FAILURE')
 try:
  internal=execute({'code':request['ticker'],'isin':request['isin'],'issuer':request['issuer'],'name':request['name']},db,archive,out)
 except Exception:return fail(result,'ENGINE_FAILURE')
 if internal['status']=='NO_HISTORY':return fail(result,'NO_HISTORY','NO_HISTORY')
 if internal['status']!='OK':
  reason=internal.get('reason','')
  code='NAV_JOIN_MISSING' if internal.get('diagnostic')=='NAV_JOIN_MISSING' else 'INVALID_DIVIDEND' if 'INVALID_DIVIDEND' in reason else 'INVALID_NAV' if reason.startswith('NAV ') else 'ENGINE_FAILURE'
  return fail(result,code)
 result.update(status='OK',start_date=internal['analysis_start'],end_date=internal['analysis_end'],observations=internal['observation_count'],dividend_events=internal['event_count'],drawdown_reduction_pp=internal['mdd_reduction_pp'])
 for public,private in [('raw','raw'),('navtr','tr')]:
  for a,b in [('mdd','mdd_pct'),('hwm_date','peak_date'),('trough_date','trough_date'),('recovery_date','recovery_date'),('recovery_days','recovery_observation_days'),('recovery_calendar_days','recovery_calendar_days')]:
   v=internal[private+'_'+b];result[public+'_'+a]=None if v=='' else v
  result[public+'_recovered']=internal[private+'_recovery_status']=='회복'
 return result
def run_many(requests, *, archive_dir, output_dir):
 return [run_one(r,archive_dir=archive_dir,output_dir=Path(output_dir)/str(i)) for i,r in enumerate(requests)]
def numeric_json(value):
 """Decimal emitted as JSON number, keeping engine precision without float conversion."""
 if isinstance(value,Decimal):
  if not value.is_finite():raise ValueError('Non-finite JSON number')
  return str(value)
 if isinstance(value,dict):return '{'+','.join(json.dumps(k,ensure_ascii=False)+':'+numeric_json(v) for k,v in value.items())+'}'
 if isinstance(value,(list,tuple)):return '['+','.join(numeric_json(v) for v in value)+']'
 return json.dumps(value,ensure_ascii=False,allow_nan=False)
def save_results(results,path):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(numeric_json(results),encoding='utf-8')
def main():
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--archive',required=True);p.add_argument('--work',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 data=json.loads(Path(a.input).read_text());results=run_many(data,archive_dir=a.archive,output_dir=a.work) if isinstance(data,list) else run_one(data,archive_dir=a.archive,output_dir=a.work)
 save_results(results,a.output)
if __name__=='__main__':main()
