"""FunETF original response preservation and explicit screen-date mapping."""
import json,hashlib,datetime,urllib.request,urllib.parse
from pathlib import Path
from decimal import Decimal
MAPPING={'KODEX':'procDt','TIGER':'gijunYmd','RISE':'gijunYmd','ACE':'gijunYmd','삼성자산운용':'procDt','미래에셋자산운용':'gijunYmd','KB자산운용':'gijunYmd','한국투자신탁운용':'gijunYmd'}
def collect(spec, destination, archive=None):
 code=spec['code']; isin=spec['isin']; field=MAPPING[spec['issuer']]
 url='https://www.funetf.co.kr/api/public/product/view/etfdividend?'+urllib.parse.urlencode({'fundCd':isin,'itemId':isin})
 if archive is not None:
  payload=(Path(archive)/(code+'.json')).read_bytes(); mode='saved_original_replay'
 else:
  request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
  with urllib.request.urlopen(request,timeout=30) as response: payload=response.read()
  mode='live'
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 (destination/(code+'.json')).write_bytes(payload)
 provenance={'code':code,'isin':isin,'issuer':spec['issuer'],'url':url,'mode':mode,'sha256':hashlib.sha256(payload).hexdigest(),'run_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_path':str(archive) if archive else None}
 (destination/(code+'_provenance.json')).write_text(json.dumps(provenance,ensure_ascii=False,indent=2))
 original=json.loads(payload,parse_float=Decimal)
 if not isinstance(original,list):raise ValueError('INVALID_DIVIDEND: response is not a list')
 events=[];seen=set()
 for index,row in enumerate(original):
  if row.get('sotCd') and row['sotCd']!=code:raise ValueError('INVALID_DIVIDEND: code mismatch')
  value=row.get(field)
  try:
   day=datetime.datetime.strptime(str(value),'%Y%m%d').date().isoformat()
   amount=Decimal(str(row['divAmt']))
   if not amount.is_finite() or amount<=0:raise ValueError('amount')
  except Exception as exc:raise ValueError('INVALID_DIVIDEND: row '+str(index)+', '+str(exc)) from exc
  key=tuple(str(row.get(k)) for k in ('gijunYmd','procDt','basicDt','payDt','divAmt'))
  if key in seen:raise ValueError('INVALID_DIVIDEND: duplicate event '+str(index))
  seen.add(key)
  events.append({'code':code,'screen_exdate':day,'screen_exdate_field':field,'amount':amount,'original':row,'source_row':index,'source_sha256':provenance['sha256']})
 return events
