"""SQLite mode=ro; retain display dates, source identifiers and values."""
import sqlite3,datetime
from decimal import Decimal
from collections import defaultdict
from pathlib import Path
def read_nav(db,code):
 with sqlite3.connect(Path(db).resolve().as_uri()+'?mode=ro',uri=True) as connection:
  connection.execute('PRAGMA query_only=ON');connection.row_factory=sqlite3.Row
  rows=[dict(r) for r in connection.execute('select n.*,r.file_hash,r.sheet,r.row_number from nav_observations n join raw_rows r on n.raw_row_id=r.id where n.code=? order by n.display_date',(code,))]
 dates=[r['display_date'] for r in rows]
 if len(dates)!=len(set(dates)):raise ValueError('NAV duplicate date')
 for row in rows:
  datetime.date.fromisoformat(row['display_date']);v=Decimal(row['nav_decimal'])
  if not v.is_finite() or v<=0:raise ValueError('NAV invalid value')
 return rows
def join(rows,events):
 dates={r['display_date'] for r in rows};amounts=defaultdict(lambda:Decimal(0));missing=[]
 for event in events:
  if event['screen_exdate'] not in dates:missing.append(event)
  else:amounts[event['screen_exdate']]+=event['amount']
 return amounts,missing
