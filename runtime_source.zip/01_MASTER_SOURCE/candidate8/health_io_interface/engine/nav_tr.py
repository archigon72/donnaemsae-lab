from decimal import Decimal,getcontext
getcontext().prec=40
def calculate(rows,amounts):
 units=Decimal(1);initial=Decimal(rows[0]['nav_decimal']);daily=[]
 for row in rows:
  nav=Decimal(row['nav_decimal']);day=row['display_date'];amount=amounts.get(day,Decimal(0));before=units
  units*=1+amount/nav
  daily.append({'date':day,'observation_id':row['id'],'raw_row_id':row['raw_row_id'],'source_sha256':row['file_hash'],'raw_nav':nav,'distribution':amount,'units_before':before,'units_after':units,'tr_index':100*units*nav/initial})
 return daily
