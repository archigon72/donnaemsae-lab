import datetime
from decimal import Decimal

def mdd(dates,values):
 p=0;peak=0;trough=0;best=Decimal(0)
 for k,v in enumerate(values):
  if v>values[p]:p=k
  dd=v/values[p]-1
  if dd<best:best=dd;peak=p;trough=k
 rec=next((k for k in range(trough+1,len(values)) if values[k]>=values[peak]),None) if best<0 else None
 return dict(mdd_pct=best*100,peak_date=dates[peak],peak_value=values[peak],trough_date=dates[trough],trough_value=values[trough],recovery_date=dates[rec] if rec is not None else '',recovery_observation_days=rec-trough if rec is not None else '',recovery_calendar_days=(datetime.date.fromisoformat(dates[rec])-datetime.date.fromisoformat(dates[trough])).days if rec is not None else '',recovery_status='회복' if rec is not None else '미회복' if best<0 else '낙폭 없음',latest_value=values[-1],latest_to_peak_pct=values[-1]/values[peak]*100,peak_index=peak,trough_index=trough,recovery_index=rec)

def calculate(rows, daily):
 dates=[r['display_date'] for r in rows]
 raw=mdd(dates,[Decimal(r['nav_decimal']) for r in rows])
 tr=mdd(dates,[r['tr_index'] for r in daily])
 result={'analysis_start':dates[0],'analysis_end':dates[-1],'observation_count':len(rows),'mdd_reduction_pp':tr['mdd_pct']-raw['mdd_pct']}
 for prefix, values in [('raw',raw),('tr',tr)]:
  result.update({prefix+'_'+k:v for k,v in values.items() if not k.endswith('_index')})
 return result
