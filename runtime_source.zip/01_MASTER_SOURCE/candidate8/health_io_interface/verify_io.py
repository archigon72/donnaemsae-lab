from pathlib import Path
from decimal import Decimal
import json,hashlib
from interface import run_one,run_many,save_results,MEASURES
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
specs=json.loads((ROOT/'funetf_health_engine/instruments.json').read_text());db=ROOT/'raw_nav_expansion_test/raw_nav_expansion.sqlite';archive=ROOT/'funetf_all_etf_test/raw'
inputs=[dict(ticker=s['code'],isin=s['isin'],issuer=s['issuer'],name=s['name'],raw_nav_source=str(db)) for s in specs]
(HERE/'sample_input_10.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2))
a=run_many(inputs,archive_dir=archive,output_dir=HERE/'run1');b=run_many(inputs,archive_dir=archive,output_dir=HERE/'run2');assert a==b
baseline={r['code']:r for r in json.loads((ROOT/'funetf_health_engine/regression/results.json').read_text(),parse_float=Decimal)}
checks=[]
for r in a:
 assert r['status']=='OK'
 s=baseline[r['ticker']]
 assert r['drawdown_reduction_pp']==Decimal(s['mdd_reduction_pp'])
 for pref,old in [('raw','raw'),('navtr','tr')]:
  for new,key in [('mdd','mdd_pct'),('hwm_date','peak_date'),('trough_date','trough_date'),('recovery_date','recovery_date'),('recovery_days','recovery_observation_days'),('recovery_calendar_days','recovery_calendar_days')]:
   expected=s[old+'_'+key]
   if key=='mdd_pct':expected=Decimal(expected)
   elif expected=='':expected=None
   assert r[pref+'_'+new]==expected,(r['ticker'],new)
  assert r[pref+'_recovered']==(s[old+'_recovery_status']=='회복')
 checks.append({'ticker':r['ticker'],'all_core_fields_match':True})
save_results(a,HERE/'sample_results_10.json')
roundtrip=json.loads((HERE/'sample_results_10.json').read_text(),parse_float=Decimal);assert a==roundtrip
single=run_one(inputs[0],archive_dir=archive,output_dir=HERE/'single');assert single==a[0]
fault=[dict(inputs[0],issuer='UNSUPPORTED'),{},inputs[1]]
f=run_many(fault,archive_dir=archive,output_dir=HERE/'failure_test');assert [r['status'] for r in f]==['FAIL','FAIL','OK']
assert all(set(r)==set(a[0]) for r in f)
# Synthetic no-history and same-date join-missing fixtures; originals unchanged.
fixtures=HERE/'fixtures';fixtures.mkdir(exist_ok=True)
original=json.loads((archive/'441640.json').read_text())
nohist=[dict(x,sotCd='999999') for x in original];(fixtures/'999999.json').write_text(json.dumps(nohist,ensure_ascii=False))
nh=run_one(dict(inputs[0],ticker='999999'),archive_dir=fixtures,output_dir=HERE/'no_history');assert nh['status']=='NO_HISTORY'
missing=[dict(x) for x in original];missing[0]['procDt']='20990101';(fixtures/'441640.json').write_text(json.dumps(missing,ensure_ascii=False))
jm=run_one(inputs[0],archive_dir=fixtures,output_dir=HERE/'join_missing');assert jm['error_code']=='NAV_JOIN_MISSING'
save_results(f+[nh,jm],HERE/'sample_failures.json')
protected=json.loads((HERE/'PRESERVATION_BEFORE.json').read_text());changed=[p for p,h in protected.items() if not Path(p).exists() or hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not changed
engine_same=all((HERE/'engine'/n).read_bytes()==(ROOT/'funetf_health_engine'/n).read_bytes() for n in ['collector.py','nav_join.py','nav_tr.py','health.py','run.py']);assert engine_same
v={'success_count':len(a),'checks':checks,'rerun_identical':True,'numeric_json_exact_roundtrip':True,'single_equals_batch':True,'failure_isolation':True,'no_history_test':True,'join_missing_test':True,'protected_count':len(protected),'changed':changed,'engine_byte_identical':engine_same,'live_api_requested':False}
(HERE/'VALIDATION.json').write_text(json.dumps(v,ensure_ascii=False,indent=2))
(HERE/'RESULT_SUMMARY.txt').write_text(f'장기체력 I/O v1.0 완료\n10/10 OK. 기존 MDD/낙폭감소/HWM/저점/회복일 및 관측·달력 회복기간 모두 일치.\n단일/복수 호출 통과. 동일 입력 재실행 동일. JSON 숫자 정밀도 보존.\n실패 격리·NO_HISTORY·NAV_JOIN_MISSING 확인. 실제 10종 실패 없음.\n기존 파일 변경 0/{len(protected)}. 엔진 5개 파일 바이트 동일. 실시간 재수신 없음.\n',encoding='utf-8')
print(json.dumps(v,ensure_ascii=False))
