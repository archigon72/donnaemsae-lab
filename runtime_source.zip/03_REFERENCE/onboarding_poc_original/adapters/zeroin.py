"""ZeroIn public adapters. Quote is JSON. Description stays on the HTML page."""
import json
import re
import urllib.request

BASE = "https://etf.zeroin.co.kr"
UA = "Mozilla/5.0"


def _get(path):
    url = BASE + path
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=40) as resp:
        return resp.status, resp.read(), url


def quote(ticker):
    status, body, url = _get(f"/api/quote/{ticker}")
    data = json.loads(body.decode("utf-8", "replace") or "{}")
    return {"status": status, "url": url, "data": data}


def page(ticker):
    status, body, url = _get(f"/etf/{ticker}")
    text = body.decode("utf-8", "replace")
    def grab(label):
        m = re.search(rf"{label}</td>\s*<td>([^<]+)", text)
        if m:
            return m.group(1).strip()
        m = re.search(rf"{label}\s*\|\s*([^|\n<]+)", text)
        return m.group(1).strip() if m else None
    strategy = None
    i = text.find("투자 전략")
    if i >= 0:
        m = re.search(r"<p[^>]*>([^<]{20,500})</p>", text[i:i + 2000])
        strategy = m.group(1).strip() if m else None
    return {
        "status": status,
        "url": url,
        "index_name": grab("기초지수"),
        "issuer": grab("운용사"),
        "listing_date": grab("상장일"),
        "fee": grab("총보수 (기타비용 제외)") or grab("총보수"),
        "strategy": strategy,
        "has_pension": "퇴직연금" in text,
    }
