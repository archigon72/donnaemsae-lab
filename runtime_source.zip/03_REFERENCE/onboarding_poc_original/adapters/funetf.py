"""FunETF public adapters. No ticker hardcoding."""
import json
import urllib.parse
import urllib.request

BASE = "https://www.funetf.co.kr"
UA = "Mozilla/5.0"


def _get(path, params):
    url = BASE + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": BASE})
    with urllib.request.urlopen(req, timeout=40) as resp:
        body = resp.read()
        return resp.status, body, url


def search(ticker):
    status, body, url = _get("/api/public/quickSearch/etf", {"keyword": ticker})
    rows = json.loads(body.decode("utf-8", "replace") or "[]")
    hit = next((r for r in rows if str(r.get("shortCode") or "").upper() == ticker.upper()), None)
    return {"status": status, "url": url, "hit": hit, "count": len(rows)}


def dividends(isin, as_of):
    status, body, url = _get(
        "/api/public/product/view/etfdividend",
        {"gijunYmd": as_of, "fundCd": isin, "itemId": isin},
    )
    rows = json.loads(body.decode("utf-8", "replace") or "[]")
    return {"status": status, "url": url, "rows": rows}


def nav(isin, as_of, start="20100101"):
    status, body, url = _get(
        "/api/public/product/view/etfnav",
        {
            "gijunYmd": as_of,
            "fundCd": isin,
            "itemId": isin,
            "schNavStDt": start,
            "schNavEdDt": as_of,
        },
    )
    rows = json.loads(body.decode("utf-8", "replace") or "[]")
    return {"status": status, "url": url, "rows": rows}
